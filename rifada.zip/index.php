<?php
  include "rss.php";
  header('location:home'); 
?>
