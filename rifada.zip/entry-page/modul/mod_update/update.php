<iframe align='center' frameborder='yes' height='400px' name='frame1' scrolling='auto' 
src='http://homemediaart.com' 
style='border: 0px solid;' width='98%'></iframe> 