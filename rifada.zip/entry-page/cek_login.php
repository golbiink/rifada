<?php
include "../config/koneksi.php";
function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['username']);
$pass     = anti_injection(md5($_POST['password']));

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  echo "Sekarang loginnya tidak bisa di injeksi lho.";
}
else{
$login=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$pass' AND blokir='N'");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);

// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  include "timeout.php";

  $_SESSION[namauser]     = $r[username];
  $_SESSION[namalengkap]  = $r[nama_lengkap];
  $_SESSION[passuser]     = $r[password];
  $_SESSION[leveluser]    = $r[level];
  
  // session timeout
  $_SESSION[login] = 1;
  timer();

	$sid_lama = session_id();
	
	session_regenerate_id();

	$sid_baru = session_id();

  mysql_query("UPDATE users SET id_session='$sid_baru' WHERE username='$username'");
  header('location:media.php?module=home');
}
else{
  echo "<style type='text/css'>
		@import url('css/style.css');
		@import url('css/forms.css');
		@import url('css/forms-btn.css');
		@import url('css/menu.css');
		@import url('css/style_text.css');
		@import url('css/datatables.css');
		@import url('css/fullcalendar.css');
		@import url('css/pirebox.css');
		@import url('css/modalwindow.css');
		@import url('css/statics.css');
		@import url('css/tabs-toggle.css');
		@import url('css/system-message.css');
		@import url('css/tooltip.css');
		@import url('css/wizard.css');
		@import url('css/wysiwyg.css');
		@import url('css/wysiwyg.modal.css');
		@import url('css/wysiwyg-editor.css');
</style>";
  echo "<div id='wrapper' class='login'>
	
	<div class='box'><br> 
	<center><h1>LOGIN GAGAL! </h1><br> 
        Username atau Password Anda tidak benar.<br>
        Atau account Anda sedang diblokir.<br>
		<a href=index.php><b>ULANGI LAGI</b></a></center><br> 
		</div>
	</div>
	
</div>";
}
}
?>
